var appURL = "http://localhost/web/hacktm/";

var mainMenuOptions = [
	//{label: "Home", url: ""},
	{label: "Schedule", url: "schedule.html"},
	{label: "Rules", url: "rules.html"},
	{label: "People", url: "people.html"},
	{label: "Projects", url: "projects.html"},
	{label: "FAQ", url: "faq.html"},
	//{label: "Despre", url: "about.html"},
	//{label: "Inscriere", url: "register.html"},
	//{label: "Alte Chestii", url: "#"},
	{label: "Contact", url: "contact.html"}
];

var footerMenuOptions = [
	{label: "Sponsors", url: "#"},
	{label: "Team", url: "#"},
	{label: "About", url: "#"},
	{label: "Register", url: "#"},
	{label: "Rules", url: "#"},
	{label: "Schedule", url: "#"},
	{label: "FAQ", url: "#"},
]
